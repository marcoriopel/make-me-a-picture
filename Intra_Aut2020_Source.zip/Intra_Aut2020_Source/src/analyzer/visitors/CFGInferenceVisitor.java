package analyzer.visitors;
import analyzer.ast.*;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.*;
import org.enoir.graphvizapi.*; // https://github.com/eternnoir/graphvizapi
import java.io.File;

/**
 *  Intra compilateur 2020
 *     Nom: Thibault
 *     Prenom: Guillaume
 *     Matricule: 1948612
 *     Dare: 25-08-2020
 */

public class CFGInferenceVisitor implements ParserVisitor {
    private boolean teacherCorrect;
    private /*final*/ PrintWriter m_writer;
    private String imgname;

    public CFGInferenceVisitor(PrintWriter writer, String filename, boolean correction) {
        m_writer = writer;
        imgname = new String(filename).replaceAll("/expected/", "/img/");
        teacherCorrect = correction;
    }

    /* * * * * * * * * * * * * * * * * * * * * * * *  NOTE  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     *   génère une nouvelle variable temporaire qu'il est possible de print
     *   À noté qu'il serait possible de rentrer en conflit avec un nom de variable définit dans le programme.
     *   Par simplicité, dans ce tp, nous ne concidérerons pas cette possibilité, mais il faudrait un générateur de nom de
     *   variable beaucoup plus robuste dans un vrai compilateur.
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    private int step = 0;
    private String genStep() {
        return "" + step++;
    }

    public HashMap<String, StepStatus> allSteps = new HashMap<>();
    public HashMap<String, HashMap<String, MegaType>> SymbolTable = new HashMap<>();

    @Override
    public Object visit(SimpleNode node, Object data) {
        return data;
    }

    @Override
    public Object visit(ASTProgram node, Object data)  {
        HashSet<String> set = new HashSet<>();
        set.add("Start");
        allSteps.put("Start", new StepStatus());
        allSteps.get("Start").chemin.add("start");

        node.childrenAccept(this, set);

        allSteps.put("Stop", new StepStatus());

        for(String e : set){
            allSteps.get(e).SUCC.add("Stop");
        }
        this.draw_CFG();
        return null;
    }

    @Override
    public Object visit(ASTBlock node, Object data) {
        node.childrenAccept(this, data);
        return null;
    }

    @Override
    public Object visit(ASTStmt node, Object data) {
        HashSet<String> set = (HashSet<String>) data;

        // give to the node a id
        String step = genStep();
        StepStatus s = new StepStatus();
        allSteps.put(step, s);

        // Add current path
        for (String e : set) {
            allSteps.get(e).SUCC.add(step);
            for(String c : allSteps.get(e).chemin) {
                allSteps.get(step).chemin.add(c + " - " + step);
            }
        }

        set.clear();
        set.add(step);

        node.childrenAccept(this, set);
        return null;
    }

    @Override
    public Object visit(ASTIfStmt node, Object data) {
        HashSet<String> set = (HashSet<String>) data;

        for (String s : set) {
            allSteps.get(s).description = "If";
        }

        // Copy to send to the children
        HashSet<String> if_status_clone = (HashSet<String>) set.clone();

        // Remove the node parent if it is an "it-then-else"
        if (node.jjtGetNumChildren() == 3)
            set.clear();

        // Visit child and add the last node visited to the data that will be return to link it to the SUCC of the next node
        for (int i = 1; i < node.jjtGetNumChildren(); i++) {
            HashSet<String> parent = (HashSet<String>) if_status_clone.clone();
            node.jjtGetChild(i).jjtAccept(this, parent);
            set.addAll(parent);
        }

        return null;
    }

    @Override
    public Object visit(ASTWhileStmt node, Object data) {
        HashSet<String> while_node = (HashSet<String>) data;

        for (String s : while_node) {
            allSteps.get(s).description = "While";
        }

        // Copy to send to the children
        HashSet<String> while_status_clone = (HashSet<String>) while_node.clone();

        // Visit child and add the last node visited to the data that will be return to link it to the SUCC of the next node
        node.jjtGetChild(1).jjtAccept(this, while_status_clone);
        for(String child : while_status_clone){
            allSteps.get(child).SUCC.addAll(while_node);
            for(String path : allSteps.get(child).chemin) {
                for (String parent : while_node) {
                    allSteps.get(parent).chemin.add(path + " - " + parent);
                }
            }
        }

        return null;
    }

    @Override
    public Object visit(ASTAssignStmt node, Object data) {
        HashSet<String> set = (HashSet<String>) data;

        HashMap<String, MegaType> path_type = new HashMap<String, MegaType>();

        for (String s : set) {
            allSteps.get(s).description = "Assign";
            // Add all path possible to obtain this line (To find possible var value)
            for(String c : allSteps.get(s).chemin) {
                path_type.put(c, new MegaType());
            }
        }

        // Get the var id and visit the node child to obtain his value
        String id = ((ASTIdentifier) node.jjtGetChild(0)).getValue();
        node.jjtGetChild(node.jjtGetNumChildren()-1).jjtAccept(this, path_type);

        // For all path added before -> Add the possible value of the var
        for(String path : path_type.keySet()){

            if (!SymbolTable.containsKey(id))
                SymbolTable.put(id, new HashMap<String, MegaType>());

            MegaType var_type = path_type.get(path);

            // If: Array / Else: Normal identifier
            if( node.jjtGetChild(1) instanceof ASTIndicesValue) {

                // Find index
                ASTIndicesValue indices_node = (ASTIndicesValue) node.jjtGetChild(1);
                Vector<Integer> index = indices_node.getValues();

                // Find last vector declaration
                String last_path_decl = findLastDeclarationPath(id, path);

                // Get the array
                MegaType mega_type_ref = (MegaType) SymbolTable.get(id).get(last_path_decl).clone();
                MegaType mega_type = mega_type_ref;
                for(int j=0; j < index.size(); j++) {
                    Integer i = index.get(j);
                    if (j == index.size() - 1){
                        // If last index array: Change the value
                        mega_type.type.set(i, var_type);

                    } else {
                        // Get the next array
                        mega_type = (MegaType) mega_type.type.get(i);
                    }
                }
                SymbolTable.get(id).put(path, mega_type_ref);

            } else {
                SymbolTable.get(id).put(path, var_type);
            }

            // Output the var, its type and its path
            m_writer.println(id + " : " + SymbolTable.get(id).get(path) + " (" + path + ")");
        }
        return null;
    }

    @Override
    public Object visit(ASTExpr node, Object data){
        return node.jjtGetChild(0).jjtAccept(this, data);
    }

    public Object visitOp(SimpleNode node, Object data) {
        if (node.jjtGetNumChildren() == 1) {
            node.jjtGetChild(0).jjtAccept(this, data);
        } else {
            HashMap<String, MegaType> path_type = (HashMap<String, MegaType>) data;

            // Create a copy of the original set
            HashMap<String, MegaType> path_type_copy = new HashMap<String, MegaType>();
            for(String s: path_type.keySet())
                path_type_copy.put(s, (MegaType) path_type.get(s).clone());

            // Create a hash map to store the max type of each path
            HashMap<String, MegaType> path_type_found = new HashMap<>();

            // For each component of the operation
            for (int i = 0; i < node.jjtGetNumChildren(); i++) {

                // Send the to children a copy of the original set to modify
                HashMap<String, MegaType> path_type_send = new HashMap<String, MegaType>();
                for(String s: path_type_copy.keySet()) { path_type_send.put(s, (MegaType) path_type_copy.get(s).clone());}
                node.jjtGetChild(i).jjtAccept(this, path_type_send);

                // Keep the max type of the component for each path
                for (String path : path_type_send.keySet()) {
                    if (!path_type_found.containsKey(path))
                        path_type_found.put(path, path_type_send.get(path));
                    else
                        path_type_found.put(path, max(path_type_found.get(path), path_type_send.get(path)));
                    // Actualise the real data
                    path_type.replace(path, path_type_found.get(path));
                }
            }

        }
        return null;
    }

    @Override
    public Object visit(ASTAddExpr node, Object data) {
        return visitOp(node, data);
    }

    @Override
    public Object visit(ASTMulExpr node, Object data) {
        return visitOp(node, data);
    }

    @Override
    public Object visit(ASTCompExpr node, Object data) {
        node.childrenAccept(this, data);
        // Comp will always return a boolean
        if (node.jjtGetNumChildren() == 2) {
            HashMap<String, MegaType> path_type = (HashMap<String, MegaType>) data;
            for(String path : path_type.keySet()) {
                MegaType mType = new MegaType();
                mType.type.add(VarType.Bool);
                path_type.replace(path, mType);
            }
        }
        return null;
    }

    @Override
    public Object visit(ASTGenValue node, Object data) {
        node.jjtGetChild(0).jjtAccept(this, data);
        return null;
    }

    @Override
    public Object visit(ASTBoolValue node, Object data) {
        if (data instanceof HashMap) {
            HashMap<String, MegaType> path_type = (HashMap<String, MegaType>) data;
            for (String c : path_type.keySet()) {
                path_type.get(c).type.add(VarType.Bool);
            }
        }
        return null;
    }

    @Override
    public Object visit(ASTIntValue node, Object data) {
        if (data instanceof HashMap) {
            HashMap<String, MegaType> path_type = (HashMap<String, MegaType>) data;
            for (String c : path_type.keySet()) {
                path_type.get(c).type.add(VarType.Int);
            }
        }
        return null;
    }

    @Override
    public Object visit(ASTDoubleValue node, Object data) {
        if (data instanceof HashMap) {
            HashMap<String, MegaType> path_type = (HashMap<String, MegaType>) data;
            for (String c : path_type.keySet()) {
                path_type.get(c).type.add(VarType.Double);
            }
        }
        return null;
    }

    @Override
    public Object visit(ASTCharValue node, Object data) {
        if (data instanceof HashMap) {
            HashMap<String, MegaType> chemin_type = (HashMap<String, MegaType>) data;
            for (String c : chemin_type.keySet()) {
                chemin_type.get(c).type.add(VarType.Char);
            }
        }
        return null;
    }

    @Override
    public Object visit(ASTIdentifier node, Object data) {
        if (data instanceof HashMap) {
            HashMap<String, MegaType> path_type = (HashMap<String, MegaType>) data;
            String id = node.getValue();
            if (SymbolTable.containsKey(id)) {
                for(String currentPath: path_type.keySet()){
                    String last_path_decl = findLastDeclarationPath(id, currentPath);

                    // If trying to get element in array
                    if(node.jjtGetParent().jjtGetNumChildren() > 1) {
                        ASTIndicesValue indices_node = (ASTIndicesValue) node.jjtGetParent().jjtGetChild(1);
                        Vector<Integer> index = indices_node.getValues();
                        MegaType mega_type = (MegaType) SymbolTable.get(id).get(last_path_decl).clone();

                        for(int j=0; j < index.size(); j++) {
                            Integer i = index.get(j);
                            if (j == index.size() - 1){
                                MegaType return_mega_type = new MegaType();
                                if (mega_type.type.get(i) instanceof MegaType) {
                                    // If it's an array, it's already a MegaType so return this megaType
                                    return_mega_type = (MegaType) mega_type.type.get(i);
                                } else {
                                    // If it's a VarType, we need to add it to a MegaType for the return
                                    return_mega_type.type.add(mega_type.type.get(i));
                                }
                                path_type.put(currentPath, return_mega_type);
                            } else {
                                mega_type = (MegaType) mega_type.type.get(i);
                            }
                        }

                    } else {
                        path_type.put(currentPath, (MegaType) SymbolTable.get(id).get(last_path_decl).clone());
                    }

                }
            } else {
                m_writer.println("===============================================\nERROR: ce message ne devrait pas apparaitre, il signifie qu'une variable n'est pas dans la SymbolTable.\n Le type de la variable est donc pas défaut set à VarType.Char\n===============================================\n");
                for (String c : path_type.keySet()) {
                    path_type.get(c).type.add(VarType.Char);
                }
            }
        }
        return null;
    }

    @Override
    public Object visit(ASTIndicesValue node, Object data) {
        node.childrenAccept(this, data);
        return null;
    }

    @Override
    public Object visit(ASTListValue node, Object data) {
        node.childrenAccept(this, data);
        return null;
    }

    // Useful to send info to child node of the AST
    private class StepStatus {
        public String description = "";
        public GraphNode node;
        public HashSet<String> SUCC      = new HashSet<String>();
        public ArrayList<String> chemin  = new ArrayList<String>();
    }

    public enum VarType {
        Bool,
        Int,
        Double,
        Char
    }

    public class MegaType {
        List<Object> type = new ArrayList<Object>();

        public String toString() {
            StringBuilder buff = new StringBuilder();
            boolean first = true;

            if (type.size() == 1) {
                return type.get(0).toString();
            }
            buff.append("[");
            for (Object e : type) {
                if (!first)
                    buff.append(", ");
                else
                    first = false;
                buff.append(e.toString());
            }
            buff.append("]");
            return buff.toString();
        }

        public Object clone() {
            MegaType mt = new MegaType();
            for (Object o : this.type) {
                if (o instanceof VarType) {
                    mt.type.add(o);
                }
                else {
                    mt.type.add(((MegaType) o).clone());
                }
            }
            return mt;
        }


    }

    public static VarType max(VarType a, VarType b) {
        if (a == VarType.Double || b == VarType.Double)
            return VarType.Double;
        else if (a == VarType.Int || b == VarType.Int)
            return VarType.Int;
        else if (a == b)
            return a;
        else
            return VarType.Int;
    }

    public static MegaType max(MegaType a, MegaType b) {

        for (int i = 0; i < a.type.size(); i++) {
            if (a.type.get(i) instanceof VarType && b.type.get(i) instanceof VarType)
                a.type.set(i, max((VarType) a.type.get(i), (VarType) b.type.get(i)));
            else if (a.type.get(i) instanceof MegaType && b.type.get(i) instanceof MegaType)
                a.type.set(i, max((MegaType) a.type.get(i), (MegaType) b.type.get(i)));
        }
        return a;
    }



    /* NE PAS MODIFIER LES FONCTIONS CI-DESSOUS */
    private void draw_CFG() // NE PAS MODIFIER CETTE FONCTION
    {
        Graphviz gv = new Graphviz();
        Graph graph = new Graph("g1", GraphType.DIGRAPH);

        for(String s : set_ordered(allSteps.keySet())) {

            allSteps.get(s).node = new GraphNode("Step" + s + "_" + allSteps.get(s).description);
            if (s.equals("Start") || s.equals("Stop")) {
                allSteps.get(s).node.addAttribute(new Attribute("shape","diamond"));
            }
            graph.addNode(allSteps.get(s).node);

        }

        for(String s : set_ordered(allSteps.keySet())) {
            for (String succ : set_ordered(allSteps.get(s).SUCC)) {
                graph.addEdge(new Edge("", allSteps.get(s).node, allSteps.get(succ).node));
            }
        }

        String type = "png";

        File out = new File(imgname);
        this.writeGraphToFile( gv.getGraphByteArray(graph, type, "100"), out ); //PROBLEME GRAPHVIZ: commentez si graphviz ne fonctionne pas
        m_writer.print("\n\n" + graph.genDotString());
    }

    public List<String> set_ordered(Set<String> s) {  // NE PAS MODIFIER CETTE FONCTION
        List<String> list = new ArrayList<String>(s);
        Collections.sort(list);

        return list;
    }

    public int writeGraphToFile(byte[] img, File to)  // NE PAS MODIFIER CETTE FONCTION
    {
        try {
            FileOutputStream fos = new FileOutputStream(to);
            fos.write(img);
            fos.close();
        } catch (java.io.IOException ioe) { System.out.println(ioe.getMessage());
            return -1; }
        return 1;
    }

    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
     *  Find the last path where the id is declare
     *      String id : Identifier to find his last value
     *      String current_path: Path (line) where the id is use
     * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
    private String findLastDeclarationPath(String id, String current_path) {
        String path_found = "";
        for(String var_path: SymbolTable.get(id).keySet()) {
            if(current_path.contains(var_path) && var_path.length() > path_found.length()) {
                path_found = var_path;
            }
        }
        return path_found;
    }

}
