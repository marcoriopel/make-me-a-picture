package org.enoir.graphvizapi;

public enum GraphType{
    DIGRAPH,GRPAH
}
