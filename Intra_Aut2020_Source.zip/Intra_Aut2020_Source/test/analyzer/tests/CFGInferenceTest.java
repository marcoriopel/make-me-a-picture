package analyzer.tests;

import analyzer.ast.ParserVisitor;
import analyzer.visitors.CFGInferenceVisitor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.io.File;
import java.util.Collection;

@RunWith(Parameterized.class)
public class CFGInferenceTest extends BaseTest {

    private static String m_test_suite_path = "./test-suite/CFGInferenceTest/data";

    public CFGInferenceTest(File file) {
        super(file);
    }

    @Test
    public void run() throws Exception {
        ParserVisitor algorithm = new CFGInferenceVisitor(m_output, m_img, true);
        runAndAssert(algorithm);
    }

    @Parameterized.Parameters(name = "{0}")
    public static Collection<Object[]> getFiles() {
        return getFiles(m_test_suite_path);
    }

}
